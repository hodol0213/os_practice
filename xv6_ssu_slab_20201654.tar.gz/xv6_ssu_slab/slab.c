#include "types.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "spinlock.h"
#include "slab.h"

#define BITMAP_SIZE PGSIZE

typedef int bool;
#define true 1
#define false 0

struct {
        struct spinlock lock;
        struct slab slab[NSLAB];
} stable;

static int sizes[NSLAB] = {16, 32, 64, 128, 256, 512, 1024, 2048};

bool get_bit(int num, int i) {
    return ((num & (1 << i)) != 0);
}
int set_bit(int num, int i) {
    return num | (1 << i);
}
int clear_bit(int num, int i) {
    int mask = ~(1 << i);
    return num & mask;
}

static bool get_bit_map(char *bitmap, int idx) {
    int b = idx / 8;
    int off = idx % 8;
    return get_bit(bitmap[b], off);
}
static void set_bit_map(char *bitmap, int idx) {
    int b = idx / 8;
    int off = idx % 8;
    bitmap[b] = set_bit(bitmap[b], off);
}
static void clear_bit_map(char *bitmap, int idx) {
    int b = idx / 8;
    int off = idx % 8;
    bitmap[b] = clear_bit(bitmap[b], off);
}

static char *get_obj(struct slab *s, int idx) {
    int p = idx / s->num_objects_per_page;
    int off = (idx % s->num_objects_per_page) * s->size;
    return s->page[p] + off;
}

void slabinit(){
	/* fill in the blank */
	initlock(&stable.lock, "stable");
   	acquire(&stable.lock);
    	for (int i = 0; i < NSLAB; i++) {
            struct slab *s = &stable.slab[i];
            s->size                = sizes[i];
            s->num_objects_per_page= PGSIZE / s->size;
            s->num_pages           = 1;
            s->num_used_objects    = 0;
            s->num_free_objects    = s->num_objects_per_page;

            s->bitmap = kalloc();
            memset(s->bitmap, 0, BITMAP_SIZE);

            s->page[0] = kalloc();
            memset(s->page[0], 0, PGSIZE);
            for (int j = 1; j < MAX_PAGES_PER_SLAB; j++)
        	s->page[j] = 0;
    	}
    	release(&stable.lock);
}

char *kmalloc(int size){
	/* fill in the blank */
	for (int i = 0; i < NSLAB; i++) {
            if (size > stable.slab[i].size)
                continue;
            struct slab *s = &stable.slab[i];

            for (int p = 0; p < s->num_pages; p++) {
		if (!s->page[p])
		    continue;
                for (int j = 0; j < s->num_objects_per_page; j++) {
                    int idx = p * s->num_objects_per_page + j;
                    if (!get_bit_map(s->bitmap, idx)) {
                        set_bit_map(s->bitmap, idx);
                        s->num_used_objects++;
                        s->num_free_objects--;
                        return get_obj(s, idx);
                    }
            	}
            }

            for (int p = 0; p < MAX_PAGES_PER_SLAB; p++) {
		if (!s->page[p]) {
                    s->page[p] = kalloc();
                    if (!s->page[p])
                  	return 0; 
                    memset(s->page[p], 0, PGSIZE);
		    s->num_pages++;

                    int idx = p * s->num_objects_per_page;
                    set_bit_map(s->bitmap, idx);
                    s->num_used_objects++;
                    s->num_free_objects += (s->num_objects_per_page - 1);
                    return get_obj(s, idx);
		}
            }
            return 0;
    	}
        return 0x00;
}

void kmfree(char *addr, int size){
	/* fill in the blank */
	for (int i = 0; i < NSLAB; i++) {
	    if (size > stable.slab[i].size)
            	continue;
            struct slab *s = &stable.slab[i];

            for (int p = 0; p < MAX_PAGES_PER_SLAB; p++) {
		if (!s->page[p]) continue;
            	char *base = s->page[p];
            	if (addr < base || addr >= base + PGSIZE)
                    continue;

            	int offset = addr - base;
            	int idx    = p * s->num_objects_per_page + (offset / s->size);

            	if (!get_bit_map(s->bitmap, idx))
                    return;

            	clear_bit_map(s->bitmap, idx);
            	s->num_used_objects--;
            	s->num_free_objects++;

            	bool all_free = true;
            	for (int j = 0; j < s->num_objects_per_page; j++) {
                    if (get_bit_map(s->bitmap, p * s->num_objects_per_page + j)) {
                    	all_free = false;
                    	break;
                    }
                }

            	if (all_free && s->num_pages > 1) {
                    kfree(s->page[p]);
                    s->page[p] = 0;
                    s->num_pages--;
                    s->num_free_objects -= s->num_objects_per_page;
            	}
                return;
            }
    	}
}

/* Helper functions */
void slabdump(){
	cprintf("__slabdump__\n");

	struct slab *s;

	cprintf("size\tnum_pages\tused_objects\tfree_objects\n");

	for(s = stable.slab; s < &stable.slab[NSLAB]; s++){
		cprintf("%d\t%d\t\t%d\t\t%d\n", 
			s->size, s->num_pages, s->num_used_objects, s->num_free_objects);
	}
}

int numobj_slab(int slabid)
{
	return stable.slab[slabid].num_used_objects;
}

int numpage_slab(int slabid)
{
	return stable.slab[slabid].num_pages;
}
