#ifndef _SEMAPHORE_H_
#define _SEMAPHORE_H_

#include "param.h"

#define NWAITERS 64 

struct semaphore {
  int value;                              
  struct proc* wait_queue[NWAITERS];     
  int front;                              
  int rear;                               
  int used;                               
};

extern struct semaphore usema[NLOCK];

void sem_init(struct semaphore *s, int value);
void sem_wait(struct semaphore *s);
void sem_post(struct semaphore *s);
void sem_destroy(struct semaphore *s);

#endif // _SEMAPHORE_H_

