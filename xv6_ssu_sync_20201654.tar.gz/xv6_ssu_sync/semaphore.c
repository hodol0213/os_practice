#include "types.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "x86.h"
#include "spinlock.h"
#include "proc.h"       
#include "semaphore.h"   
#include "defs.h"        

extern struct {
  struct spinlock lock;
  struct proc proc[NPROC];
} ptable;

void
sem_init(struct semaphore *s, int init_value)
{
  s->value = init_value;
  s->front = 0;
  s->rear = 0;
  s->used = 1;
}

void
sem_wait(struct semaphore *s)
{
  acquire(&ptable.lock);

  s->value--;
  if(s->value < 0) {
    if ((s->rear - s->front) >= NWAITERS) {
      panic("semaphore wait queue overflow");
    }

    s->wait_queue[s->rear % NWAITERS] = myproc();
    s->rear++;

    myproc()->state = SLEEPING;
    sched();  
  }

  release(&ptable.lock);
}

void
sem_post(struct semaphore *s)
{
  acquire(&ptable.lock);

  s->value++;
  if (s->value <= 0) {
    struct proc *p = s->wait_queue[s->front % NWAITERS];
    s->front++;

    if (p != 0) {
      p->state = RUNNABLE;
    }
  }
  
  release(&ptable.lock);
}

void
sem_destroy(struct semaphore *s)
{
  acquire(&ptable.lock);

  s->used = 0;
  s->value = 0;
  s->front = 0;
  s->rear = 0;

  for (int i = 0; i < NWAITERS; i++) {
    s->wait_queue[i] = 0;
  }

  release(&ptable.lock);
}
